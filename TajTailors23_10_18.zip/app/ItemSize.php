<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemSize extends Model
{
    protected $table = 'item_size';
    public $timestamps = false;
}
