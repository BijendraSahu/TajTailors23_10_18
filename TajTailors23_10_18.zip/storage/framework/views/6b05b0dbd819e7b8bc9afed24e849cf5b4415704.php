<input type="hidden" id="products_count" value="<?php echo e($items_count); ?>"/>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product_block">
        <?php if($item->special_price > 0): ?>
            <div class="save_amt">Save Rs. <?php echo e($item->price-$item->special_price); ?></div>

            <div class="product_amt"><span class="product_amt_less"><i
                            class="mdi mdi-currency-inr"></i><?php echo e(number_format($item->price,2)); ?></span><span
                        class="product_amt_real"> <i
                            class="mdi mdi-currency-inr"></i><?php echo e(number_format($item->special_price,2)); ?></span>
            </div>
        <?php else: ?>
            <span class="product_amt_real"><i
                        class="mdi mdi-currency-inr"></i><?php echo e(number_format($item->price,2)); ?></span>
        <?php endif; ?>
        <div class="product_img">
            <?php $image = \App\ItemImages::where(['item_master_id' => $item->id])->first(); ?>
            <?php if(isset($image)): ?>
                <img src="<?php echo e(url('p_img').'/'.$item->id.'/'.$image->image); ?>">
            <?php else: ?>
                <img src="<?php echo e(url('images/default.png')); ?>">
            <?php endif; ?>
            <div class="hover_center_block" data-toggle="modal" data-target="#Modal_ViewProductDetails" id="<?php echo e($item->id); ?>" onclick="getItemDetails(this)">
                <div class="product_hover_block">
                    <div class="mdi mdi-magnify"></div>
                </div>
            </div>
        </div>
        <div class="product_name"><a class="product_details_link" href="<?php echo e(url('view_product').'/'.encrypt($item->id)); ?>">
                <?php echo e($item->name); ?></a></div>
        <div class="availability_product_container">
            <?php
            //            $sizes = \App\ItemSize::where(['item_master_id' => $item->id])->get();
            $sizes = DB::select("select * from item_size where item_master_id = $item->id and qty > 0"); //\App\ItemSize::where(['item_master_id' => $item->id])->get();
            $count = 1;
            ?>
            <?php if(count($sizes)>0): ?>
                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="<?php echo e($item->id); ?>" class="available_box <?php echo e($count == 1 ?'avail_selected':''); ?>"
                         onclick="Select_Availability(this);"><?php echo e($size->size); ?></div>
                    <?php $count++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <?php if(count($sizes)>0): ?>
            <div class="spinner_withbtn">
                <div class="input-group qty_box">
                    <span class="qty_txt">Qty</span>
                    <input type="number" class="form-control text-center qty_edittxt" min="1" max="10"
                           value="1" id="qty_<?php echo e($item->id); ?>">
                </div>
                <button class="spinner_addcardbtn btn-primary" type="button" onclick="AddTOcart(this);">
                    <i class="mdi mdi-cart"></i> <span class="button-group_text">Add</span></button>
                <button class="spinner_addcardbtn btn-primary" id="<?php echo e($item->id); ?>" type="button"
                        data-content="<?php echo e($item->id); ?>"  onclick="AddTOcart(this);"><i id="<?php echo e($item->id); ?>" class="mdi mdi-basket"></i>
                    <span class="button-group_text">Add</span>
                </button>
            </div>
        <?php else: ?>
            <div class="notify_block long_notifyblock">
                <div class="out_of_stock">Out Of Stock</div>
                <div class="notify_me_btn" data-toggle="modal" onclick="getItemid(<?php echo e($item->id); ?>)" data-target="#Modal_NotifyMe">Notify Me
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

